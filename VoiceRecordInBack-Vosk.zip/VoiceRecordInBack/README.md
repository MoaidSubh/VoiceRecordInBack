# VoiceRecordInBack (Vosk live text edition)

Records the sound playing on an Android phone (for example a video in YouTube, Facebook, a browser or a video player), saves it as a WAV file, and writes live English text while it plays. Speech recognition runs offline on the phone using Vosk.

Developed by Dr.-Eng. Moaid Subh, Subh Engineering (Software.dr.subh@gmail.com)

## Requirements
- Android 10 or newer
- About 40 MB for the English speech model, downloaded once inside the app

## Get the APK without installing anything (GitHub, free)
1. Sign in at github.com and create a new repository, for example `VoiceRecordInBack`. It can be private.
2. Click **Add file → Upload files** and drag in **all the files and folders from this zip**. Include the hidden `.github` folder; if your file manager hides it, turn on "show hidden files".
3. Click **Commit changes**. GitHub starts building by itself.
4. Open the **Actions** tab, then the latest **Build APK** run, which takes about 5–8 minutes.
5. When it shows a green tick, download **VoiceRecordInBack-APK** under *Artifacts*. Unzip it on your phone and install `VoiceRecordInBack.apk`, allowing "install unknown apps" if Android asks.

## Or build in Android Studio
Open the folder in Android Studio and let it sync, then use **Build → Build APK(s)**.

## How to use
1. On first launch, tap **Download model**. If the download fails, download
   https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip on a computer, copy it to the phone, and tap **Import zip**.
2. Tap **Start recording**. Allow audio and notifications, then choose **Entire screen** and **Start** in Android's capture prompt.
3. Switch to your video app and play the video. Recording continues in the background, shown by a notification.
4. Return to the app to watch the live text, or stop from the notification.
5. **Recordings** lists each session with options to read text, play, share, rename or delete. Every transcript line has a time stamp, e.g. `[01:23] Hello everyone`.

## Limits (set by Android)
- Apps that block capture, such as Netflix and other DRM streaming apps, record as silence.
- Phone calls are not captured.
- Android asks for capture permission at the start of every session.
- Text accuracy is good for clear speech and lower with loud music or noise. A later edition will add Whisper for higher accuracy.

Files are stored in `Android/data/com.subhengineering.voicerecordinback/files/Recordings/`.
