plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.subhengineering.voicerecordinback"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.subhengineering.voicerecordinback"
        minSdk = 29          // Android 10 — required for capturing playback audio
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        ndk {
            // Phones only; keeps the APK smaller
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        // Fixed key so every new build installs over the previous one
        create("subh") {
            storeFile = file("subh.jks")
            storePassword = "subh2026"
            keyAlias = "subh"
            keyPassword = "subh2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("subh")
        }
        debug {
            signingConfig = signingConfigs.getByName("subh")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Vosk offline speech recognition
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}
