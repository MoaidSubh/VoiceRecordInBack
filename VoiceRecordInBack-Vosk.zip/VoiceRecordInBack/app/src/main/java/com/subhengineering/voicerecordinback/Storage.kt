package com.subhengineering.voicerecordinback

import android.content.Context
import java.io.File

object Storage {
    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, "Recordings").apply { mkdirs() }
    }
}
