package com.subhengineering.voicerecordinback

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max

/**
 * Foreground service that captures the sound other apps are playing
 * (Android 10+ AudioPlaybackCapture), saves it as WAV, and feeds it to
 * Vosk for live English text.
 */
class RecordService : Service() {

    companion object {
        const val ACTION_START = "com.subhengineering.voicerecordinback.START"
        const val ACTION_STOP = "com.subhengineering.voicerecordinback.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "recording"
        private const val NOTIF_ID = 1
        private const val SAMPLE_RATE = 16000
        private const val BYTES_PER_SEC = SAMPLE_RATE * 2
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var running = false
    @Volatile private var finishing = false
    private var lastLine = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                if (worker == null) stopSelf() else running = false
            }
            ACTION_START -> if (worker == null) start(intent)
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        createChannel()
        // Must be in the foreground BEFORE asking for the MediaProjection (Android 14 rule)
        startForeground(NOTIF_ID, buildNotification("Starting…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = if (data != null) mpm.getMediaProjection(code, data) else null
        if (proj == null) {
            LiveState.error.value = "Capture permission was not granted."
            shutdown()
            return
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { running = false } // user revoked from system UI
        }, main)

        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VoiceRecordInBack:rec").apply {
            setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L)
        }

        LiveState.reset()
        LiveState.isRecording.value = true
        running = true
        worker = thread(name = "capture") { captureLoop(proj) }
    }

    @SuppressLint("MissingPermission") // RECORD_AUDIO is checked in MainActivity
    private fun captureLoop(proj: MediaProjection) {
        var recognizer: Recognizer? = null
        var record: AudioRecord? = null
        var wav: WavWriter? = null
        var txt: File? = null
        var totalBytes = 0L
        var uttStart = 0L

        fun addFinal(json: String) {
            val text = JSONObject(json).optString("text", "").trim()
            if (text.isEmpty()) return
            val sec = uttStart / BYTES_PER_SEC
            val line = String.format(Locale.US, "[%02d:%02d] %s", sec / 60, sec % 60,
                text.replaceFirstChar { it.uppercase() })
            LiveState.appendLine(line)
            lastLine = line
            txt?.appendText(line + "\n")
        }

        try {
            LiveState.status.value = "Loading speech model…"
            val model = ModelManager.get(this)
            recognizer = Recognizer(model, SAMPLE_RATE.toFloat())

            val config = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            record = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(max(minBuf * 4, BYTES_PER_SEC))
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("Could not start audio capture on this phone.")
            }

            val base = "Rec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val dir = Storage.dir(this)
            wav = WavWriter(File(dir, "$base.wav"), SAMPLE_RATE)
            txt = File(dir, "$base.txt").apply {
                writeText("VoiceRecordInBack transcript\n" +
                    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + "\n\n")
            }

            record.startRecording()
            LiveState.status.value = "Recording — play your video now"

            val buf = ByteArray(3200) // 100 ms of audio
            var lastNotif = 0L
            while (running) {
                val n = record.read(buf, 0, buf.size)
                if (n < 0) throw IllegalStateException("Audio capture error ($n)")
                if (n == 0) continue
                wav.write(buf, n)
                totalBytes += n
                LiveState.elapsedSec.value = totalBytes / BYTES_PER_SEC

                if (recognizer.acceptWaveForm(buf, n)) {
                    addFinal(recognizer.result)
                    LiveState.partial.value = ""
                    uttStart = totalBytes
                } else {
                    val p = JSONObject(recognizer.partialResult).optString("partial", "")
                    if (p.isEmpty()) uttStart = totalBytes // speech hasn't started yet
                    if (p != LiveState.partial.value) LiveState.partial.value = p
                }

                val now = System.currentTimeMillis()
                if (now - lastNotif > 1000) {
                    lastNotif = now
                    val s = totalBytes / BYTES_PER_SEC
                    val t = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
                    updateNotification(if (lastLine.isEmpty()) "Recording $t" else "$t  $lastLine")
                }
            }
            recognizer.finalResult.let { addFinal(it) }
        } catch (e: Throwable) {
            LiveState.error.value = e.message ?: e.toString()
        } finally {
            try { record?.stop() } catch (_: Exception) {}
            try { record?.release() } catch (_: Exception) {}
            try { wav?.close() } catch (_: Exception) {}
            try { recognizer?.close() } catch (_: Exception) {}
            LiveState.partial.value = ""
            LiveState.status.value = if (totalBytes > 0) "Saved — see Recordings" else "Ready"
            main.post { shutdown() }
        }
    }

    private fun shutdown() {
        if (finishing) return
        finishing = true
        running = false
        LiveState.isRecording.value = false
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    // ---------- Notification ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, RecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Recording sound + live text")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp)
            .addAction(0, "Stop", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        if (finishing) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
